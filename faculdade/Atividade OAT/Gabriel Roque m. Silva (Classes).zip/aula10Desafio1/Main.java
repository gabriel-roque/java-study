package aula10Desafio1;

public class Main {

    public static void main(String[] args) {

        Processa usuario = new Processa();
        usuario.run();

    }
}


