package aula10Desafio2;

public class Main {
    public static void main(String[] args) {

        Processa p1 = new Processa();
        p1.run();

    }
}
