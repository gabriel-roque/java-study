package desafio02Swing;

public class Controlador extends Aluno{

    private Aluno aluno[];
    private int pos;
    private Aluno alunosCadastradosFrame;


    public Aluno[] getAluno() {
        return aluno;
    }

    public void cadastrarAluno(){
        //
    }

    public void salvarAlunos(){
        //
    }

    public boolean salvarAlunos(Boolean parm){

        //digrama nao especificar o nome do parametro
        return parm;

    }

    public void listarAlunos(){
        //
    }

    public void editarAlunos(){
        //
    }

    public double calcularMedia(double parm){

        return parm;

    }





}
