package desafio02Swing.view;

import desafio02Swing.controller.Controlador;

import javax.swing.*;

public class TurmaFrame{

    private JButton listarAlunosButton,
                    resultadosButton,
                    novoAlunoButton;

    private Controlador controlador;


    private void thisWindowClosing(){
        //
    }

    private void novoAlunoButtunActionPerformed(){
        //
    }

    private void resultadosButtonActionPerformed(){
        //
    }

    public static void main(String[] args) {
        //
    }
}
