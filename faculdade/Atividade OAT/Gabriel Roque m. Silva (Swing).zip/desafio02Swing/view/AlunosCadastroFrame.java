package desafio02Swing.view;

import desafio02Swing.controller.Controlador;

import javax.swing.*;

public class AlunosCadastroFrame{

    private JMenuItem cadastrarMenuItem;
    private JMenuItem editarMenuItem;
    private JList alunosLista;
    private Controlador controlador;


    public void carregarDados(){
        //
    }

    private void cadastrarMenuItemActionPerformed(){
        //
    }

    private void editarMenuItemActionPerformed(){
        //
    }

    public void atualozarDados(){
        //
    }




}
