package desafio02Swing;

import javax.swing.*;

public class AlunosCadastroFrame extends Controlador{

    private JMenuItem cadastrarMenuItem;
    private JMenuItem editarMenuItem;
    private JList alunosLista;
    private Controlador controlador;


    public void carregarDados(){
        //
    }

    private void cadastrarMenuItemActionPerformed(){
        //
    }

    private void editarMenuItemActionPerformed(){
        //
    }

    public void atualozarDados(){
        //
    }




}
