package desafio02Swing.controller;

import desafio02Swing.model.Aluno;

public class Controlador{

    private Aluno aluno[];
    private int pos;
    private Aluno alunosCadastradosFrame;


    public Aluno[] getAluno() {
        return aluno;
    }

    public void cadastrarAluno(){
        //
    }

    public void salvarAlunos(){
        //
    }

    public boolean salvarAlunos(Boolean parm){

        //digrama nao especificar o nome do parametro
        return parm;

    }

    public void listarAlunos(){
        //
    }

    public void editarAlunos(){
        //
    }

    public double calcularMedia(double parm){

        return parm;

    }
}
