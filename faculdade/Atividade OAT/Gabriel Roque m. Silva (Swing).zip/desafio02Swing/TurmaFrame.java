package desafio02Swing;

import javax.swing.*;

public class TurmaFrame extends Controlador{

    private JButton listarAlunosButton,
                    resultadosButton,
                    novoAlunoButton;

    private Controlador controlador;


    private void thisWindowClosing(){
        //
    }

    private void novoAlunoButtunActionPerformed(){
        //
    }

    private void resultadosButtonActionPerformed(){
        //
    }

    public static void main(String[] args) {
        //
    }
}
