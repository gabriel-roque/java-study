public class DadosCombinacao {
    public static void main(String[] args) {

        int c, j = 0;

        for (c = 1; c <= 6; c++){
            for (j = 1; j <= 6; j++){

                System.out.println("Dado A lado " + c + " com Dado B lado " + j);

            }

            System.out.println("===============================");

        }
    }
}
